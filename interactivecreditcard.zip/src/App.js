import React from 'react';
import './App.scss';
import HomePage from './HomePage';

function App() {
  return <HomePage/>;
}

export default App;
